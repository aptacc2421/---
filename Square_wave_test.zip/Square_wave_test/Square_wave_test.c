/*
 * Copyright (c) 2021, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "ti_msp_dl_config.h"
#include "ti/iqmath/include/IQmathLib.h"
#include "arm_math.h"
#include "arm_const_structs.h"

#define FFT_LEN 1024


int16_t adc_buffer[FFT_LEN];



// 3. Blackman-Harris窗系数 (预计算浮点)
float voltage[FFT_LEN] = { 0.0f };
float fft_output[(FFT_LEN*2)] = { 0.0f };
float fft_mag[FFT_LEN/2] = { 0.0f };
float temp[1024];

float fre;
float amp;
float offset_val;
float mea__fre;
    float bin;

typedef struct{
    float fre;
    float amp;
    float vpp;
    float offset;
}Wave_Data;

Wave_Data wave;

/**************************计算参数*********************** */
float peak_voltage;
float vall_voltage;
float duty;
float mea_fre;
uint32_t arr;



volatile uint8_t flag=0;//不加volatile可能使flag被优化从而使while1进入死循环


uint16_t Max_Float(float *Mag, uint16_t len);
uint16_t Max_Float_WithinRange(float Data[], uint16_t Left, uint16_t Right);

void Add_Hanning_Window(float voltage[], uint16_t len) ;
void Add_Top_Window(float voltage[], uint16_t len);
float Get_Fre_First(float fft_mag[], float simple_rate, uint16_t len, uint16_t index);
void execute_fft(float windowedData[], float fft_output[], float fft_mag[], uint16_t len) ;
void Act_FFT(float voltage[], float fft_output[], float fft_mag[],  uint16_t len, uint8_t window_type ,float *offset_val);
void test_funk(float voltage[], float fft_output[], float fft_mag[],  uint16_t len ,Wave_Data *wave, float simple_rate);

void Transform_ADC_to_Voltage(float *voltage)
{
	for(uint16_t i=0;i<FFT_LEN;i++){
		voltage[i] =(float)adc_buffer[i]*3.3f/4095.0f;
	}
}

float Set_TimerA_psc( uint32_t arr_1);


/**************************计算函数*********************** */
void Get_Jvxingbo_fre_And_Up_And_Down( float voltage[], uint16_t len, float *peak_voltage, float *vall_voltage, float *duty,float *fre, float fazhi);



int main(void)
{
    SYSCFG_DL_init();
    DL_DMA_setSrcAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t)0x40556280);  
    DL_DMA_setDestAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t)adc_buffer); 
    DL_DMA_enableChannel(DMA, DMA_CH0_CHAN_ID );
    NVIC_EnableIRQ(ADC12_0_INST_INT_IRQN);


   

    //Set_TimerA_psc( 2000);//设置采样频率为40kHz
    //DL_TimerA_startCounter(TIMER_0_INST);
    while (1) {


        Get_Jvxingbo_fre_And_Up_And_Down( voltage, FFT_LEN, &peak_voltage, &vall_voltage, &duty, &fre, 0.3);

        flag=0;
        __BKPT();
        

      // DL_TimerA_startCounter(TIMER_0_INST);
        
       
        
        
      
    }
}
void HardFault_Handler(){
    __BKPT();
}

/**
 * @brief 查找数组中第二大值和第二小值的索引
 * @param shuzu 输入的浮点数数组
 * @param len 数组长度
 * @param second_max_index 存储第二大值索引的指针（未找到时设为0xFFFF）
 * @param second_min_index 存储第二小值索引的指针（未找到时设为0xFFFF）
 * 
 * @注意 
 * 1. 使用0xFFFF(65535)表示无效索引
 * 2. 处理数组元素重复的情况
 * 3. 数组元素少于2个或所有元素相同时返回无效索引
 */
void Get_Second_Index(float shuzu[], uint16_t len, 
                      uint16_t *second_max_index, 
                      uint16_t *second_min_index) 
{
    // 初始化为无效索引(0xFFFF)
    *second_max_index = 0xFFFF;
    *second_min_index = 0xFFFF;
    
    // 处理数组长度小于2的情况
    if (len < 2) {
        return;
    }

    // 初始化最大值/最小值及其索引
    float max_val = shuzu[0];
    float min_val = shuzu[0];
    uint16_t max_idx = 0;
    uint16_t min_idx = 0;
    
    // 初始化第二大/第二小值
    float second_max = -FLT_MAX;  // 初始设为最小浮点数
    float second_min = FLT_MAX;   // 初始设为最大浮点数

    // 从第二个元素开始遍历数组
    for (uint16_t i = 1; i < len; i++) {
        float current = shuzu[i];
        
        // 更新最大值和第二大值
        if (current > max_val) {
            second_max = max_val;       // 原最大值变为第二大值
            *second_max_index = max_idx;
            max_val = current;          // 更新最大值
            max_idx = i;
        } 
        // 当前值介于最大值和第二大值之间
        else if (current < max_val && current > second_max) {
            second_max = current;
            *second_max_index = i;
        }
        
        // 更新最小值和第二小值
        if (current < min_val) {
            second_min = min_val;       // 原最小值变为第二小值
            *second_min_index = min_idx;
            min_val = current;          // 更新最小值
            min_idx = i;
        } 
        // 当前值介于最小值和第二小值之间
        else if (current > min_val && current < second_min) {
            second_min = current;
            *second_min_index = i;
        }
    }
    
    // 处理特殊情况：数组所有元素相同
    if (*second_max_index == 0xFFFF || *second_min_index == 0xFFFF) {
        *second_max_index = 0xFFFF;
        *second_min_index = 0xFFFF;
    }
}


float Set_TimerA_psc( uint32_t arr_1) {
    float fre;
    if(arr_1<80){//使采样频率最高不超过1MHz
        arr_1 = 80;
    }
    else if (arr_1>40000) {{
        arr_1 = 40000;
    }
    
    }
    arr_1 = (arr_1 > 1) ? arr_1 : 1;  // 确保最小值1
    
    DL_TimerA_stopCounter(TIMER_0_INST);        // 停止定时器
    DL_TimerA_setLoadValue(TIMER_0_INST, arr_1 - 1);  // 修正：设置ARR值
    DL_TimerA_setTimerCount(TIMER_0_INST, 0);   // 计数器归零
   
     DL_TimerA_startCounter(TIMER_0_INST);     // 按需启用
    
    // 修正频率计算公式
    fre = 80000000.0f /  (float)arr_1;  // 80MHz时钟源
    __NOP();
    return fre;
}

void ADC12_0_INST_IRQHandler(void){
    switch (DL_ADC12_getPendingInterrupt(ADC12_0_INST)) {
        case DL_ADC12_IIDX_DMA_DONE:
        DL_TimerA_stopCounter(TIMER_0_INST);
        Transform_ADC_to_Voltage(voltage);
        flag=1;
		
        break;
        default:
        break;
    
    }
}


/**********************************************************计算方波的函数***************************************************** */

/**
 * @brief 获得矩形波的峰值谷值和占空比
 * @param voltage[]矩形波电压数组（含两个周期以上,20个周期以下）
 * @param len 数组长度
 * @param peak_voltage 峰值
 * @param vall_voltage 谷值
* @param duty 占空比
* @param fazhi 认为它是峰值谷值的最大偏移量
 */
 
void Get_Jvxingbo_fre_And_Up_And_Down(float voltage[], uint16_t len, float *peak_voltage, float *vall_voltage, float *duty,float *fre,float fazhi){
    uint16_t left_index,right_index,second_max_index,second_min_index,index_up_start_index,index_up_end_index,index_down_start_index,index_down_end_index;
    uint16_t index_up_start[20];
    uint16_t index_up_end[20];
    uint16_t index_down_start[20];
    uint16_t index_down_end[20];
    uint8_t start_from_up;
    float peak;
    float vall;
    float peak_sum;
    float vall_sum;
    float frequence;
    uint16_t down_num;
    uint16_t up_num;
    uint16_t fre_index_sum;


    arr = DL_TimerA_getLoadValue(TIMER_0_INST);
    mea_fre = 8e7/(float)(arr+1);

    left_index=right_index=
    second_max_index=second_min_index=
    index_up_start_index=index_up_end_index=index_down_start_index=index_down_end_index=0;

    Get_Second_Index(voltage,len, &second_max_index,  &second_min_index);
    peak = voltage[second_max_index];
    vall = voltage[second_min_index];
    float medium = (peak + vall)/2;
    fazhi = fazhi > (peak-vall)/2? (peak-vall)/2 : fazhi;//加个保险
    start_from_up = voltage[0]>medium? 1: 0;
    if(start_from_up!=0){//如果波形从峰值开始
        for(uint16_t i=1;i<len;i++){
            if(voltage[i-1]> peak - fazhi && voltage[i]< peak - fazhi){//峰->谷
                
                index_up_end[index_up_end_index++]=i-1;

            }
            if(voltage[i-1] > vall + fazhi && voltage[i] < vall + fazhi){//峰->谷
                
                index_down_start[index_down_start_index++]=i;
            }
            if(voltage[i-1] < vall + fazhi && voltage[i] > vall + fazhi){//谷->峰
                index_down_end[index_down_end_index++]=i-1;
            }
            if(voltage[i-1] < peak - fazhi && voltage[i] > peak - fazhi){//谷->峰
                index_up_start[index_up_start_index++]=i;
            }



        }
    }
    else{//如果波形从谷值开始
         for(uint16_t i=1;i<len;i++){
            if(voltage[i-1] < vall + fazhi && voltage[i] > vall + fazhi){//谷->峰
                index_down_end[index_down_end_index++]=i-1;
            }
            if(voltage[i-1] < peak - fazhi && voltage[i] > peak - fazhi){//谷->峰
                    index_up_start[index_up_start_index++]=i;
            }
            if(voltage[i-1]> peak - fazhi && voltage[i]< peak - fazhi){//峰->谷
                
                index_up_end[index_up_end_index++]=i-1;

            }
            if(voltage[i-1] > vall + fazhi && voltage[i] < vall + fazhi){//峰->谷
                
                index_down_start[index_down_start_index++]=i;
            }


        }
    }
    for(uint16_t i=index_up_start_index;i<20;i++){index_up_start[i]=0;}
    for(uint16_t i=index_up_end_index;i<20;i++){index_up_end[i]=0;}
    for(uint16_t i=index_down_start_index;i<20;i++){index_down_start[i]=0;}
    for(uint16_t i=index_down_end_index;i<20;i++){index_down_end[i]=0;}
    down_num=0;
    up_num=0;
    vall_sum=0;
    peak_sum=0;
    //进入测量
    if(index_up_end[0]<index_down_end[0]){//如果波形从峰值开始
        for(uint16_t j = 0; j<index_up_end_index-1; j++){
          
                for(uint16_t k=index_down_start[j];k<=index_down_end[j];k++){
                    vall_sum += voltage[k];
                    down_num++;
                }
            
            
                for(uint16_t k=index_up_start[j];k<=index_up_end[j+1];k++){
                    peak_sum += voltage[k];
                    up_num++;
             
            }
        }
        fre_index_sum = index_up_end[index_up_end_index-1] - index_down_start[0];//数组记住要减1！！！！！！！！！！！！！！！！
        frequence =  mea_fre/((float)fre_index_sum/(float)(index_up_end_index-1));

    }
    else{
        for(uint16_t j = 0; j<index_down_end_index-1; j++){

                for(uint16_t k=index_up_start[j];k<=index_up_end[j];k++){
                    peak_sum += voltage[k];
                    up_num++;
                }
            
               
                for(uint16_t k=index_down_start[j];k<=index_down_end[j+1];k++){
                    vall_sum += voltage[k];
                    down_num++;
                }
               // __asm("NOP");
            
        }
        fre_index_sum = index_down_end[index_down_end_index-1] - index_up_start[0];
        frequence =  mea_fre/((float)fre_index_sum/(float)(index_down_end_index-1));
    }
    peak=(float)peak_sum/(float)up_num;
    vall=(float)vall_sum/(float)down_num;
    *peak_voltage=peak;
    *vall_voltage=vall;
    *duty=(float)up_num/(float)(up_num+down_num);
    *fre = frequence;
}


uint16_t Min_Float_WithinRange(float Data[], uint16_t Left, uint16_t Right)
{
    uint16_t i, MinIndex;
    MinIndex = Left;
    for (i = Left; i <= Right; ++i)
    {
        if (Data[MinIndex] > Data[i])
        {
            MinIndex = i;
        }
    }
    return MinIndex;
}

/************************************************************以下是fft的函数*******************************************/
		///* 找出最大浮点数 */
		///* 找出最大浮点数 */
uint16_t Max_Float(float *Mag, uint16_t len)
{
    uint16_t i, Fn_Num;
    Fn_Num = 0;
    Mag[Fn_Num] = Mag[1];
    for (i = 1; i < len - 1; i++)
    {
        if (Mag[Fn_Num] < Mag[i])
        {
            Fn_Num = i;
        }
    }
    return Fn_Num;
}

uint16_t Max_Float_WithinRange(float Data[], uint16_t Left, uint16_t Right)
{
    uint16_t i, MaxIndex;
    MaxIndex = Left;
    for (i = Left; i <= Right; ++i)
    {
        if (Data[MaxIndex] < Data[i])
        {
            MaxIndex = i;
        }
    }
    return MaxIndex;
}

// 2. 生成窗
void Add_Hanning_Window(float voltage[], uint16_t len) {
    for(uint32_t i=0; i<len; i++) {
        voltage[i] *= 0.5f * (1.0f - cosf(2*PI*i/(len-1)));
    }
}

void Add_Top_Window(float voltage[], uint16_t len) {
    // 使用IEC标准系数
    const float a0 = 1.0000000;
    const float a1 = 1.9125109;
    const float a2 = 1.0791733;
    const float a3 = 0.1832631;
    const float a4 = 0.0310266;
    
    for (int i = 0; i < len; i++) {
        float32_t x = 2 * PI * i / (len - 1);
        voltage[i] *= a0 
                          - a1 * arm_cos_f32(x) 
                          + a2 * arm_cos_f32(2*x) 
                          - a3 * arm_cos_f32(3*x) 
                          + a4 * arm_cos_f32(4*x);

    }
  
}


float Get_Fre_First(float fft_mag[], float simple_rate, uint16_t len, uint16_t index){
	
	float  fre;

	float y0 = fft_mag[index - 1];
    float y1 = fft_mag[index];
    float y2 = fft_mag[index + 1];
    
    // 精确频率
    float delta = 0.5f * (y2 - y0) / ( 2*y1 -y0 - y2);
    fre = (index + delta) * simple_rate/(float)len;
	return fre;
}

// 4. 执行FFT
void execute_fft(float windowedData[], float fft_output[], float fft_mag[], uint16_t len)  {

    for(uint16_t i=0;i<len;i++){
        fft_output[2*i] = windowedData[ i ];
		fft_output[2*i+1]=0;//Ðé²¿È«²¿Îª0
    }
        // 执行FFT

    arm_cfft_f32(&arm_cfft_sR_f32_len1024 , fft_output , 0 , 1);
    // 执行FFT  
    // 计算幅度谱
   arm_cmplx_mag_f32(fft_output,fft_mag,len/2);
   		fft_mag[ 0 ] /= len;
		for(uint16_t i=1;i<len/2;i++){fft_mag[ i ] /= (len/2);}
					
}

//执行FFT
void Act_FFT(float voltage[], float fft_output[], float fft_mag[],  uint16_t len, uint8_t window_type ,float *offset_val){
//除去直流
   
    
    arm_mean_f32(voltage, len, offset_val);
	 for(uint32_t i=0; i<len; i++) {
        voltage[i] = (voltage[i] - *offset_val);
    }
  

	switch (window_type){		
		case 1:
			Add_Hanning_Window(voltage, len) ;
		break;
		case 2://平顶窗不能去直流，去直流则
			Add_Top_Window(voltage , len);
		break;
		default :			
			break;
	}
		
	execute_fft( voltage, fft_output, fft_mag, len) ;
	
}

